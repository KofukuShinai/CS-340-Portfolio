from pymongo import MongoClient
from bson.objectid import ObjectId

class CRUD:

    def __init__(self, USER, PASS):
        #USER = 'aacuser'
        #PASS = 'Kofuku'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31324
        DB = 'AAC'
        COL = 'animals'
        
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]


    def create(self, data):
        """
 Inserts a document into the specified MongoDB collection.

 Args:
     document: A dictionary representing the document to be inserted.

 Returns:
     True if insertion is successful, False otherwise.
         """

        if data is not None:
        # if passed data is not empty, attempt to insert the document
            try:
                result = self.collection.insert_one(data)
                print(f"Inserted document with _id: {result.inserted_id}")
                return True
        # Exception to throw if document cannot be inserted
            except Exception as e:
                print(f"Error creating document: {e}")
                return False
            finally:
                if self.client:
                    self.client.close()
                else:
                    print("Nothing to save, because data parameter is empty")
                    return False
    def read(self, query):
        """
        Queries for documents from the specified MongoDB collection.

        Args:
            query: A dictionary representing the query to be applied.

        Returns:
            A list of documents matching the query, or an empty list if no documents are found.
        """

        try:
            results = list(self.collection.find(query))
            return results
        except Exception as e:
            print(f"Error reading document(s): {e}")
            return None
        finally:
            if self.client:
                self.client.close()

    def update(self, filter_criteria, update_data, update_many=False):
        # chooses to update one or many based on passed variable
        # if document(s) are updated succesfully it returns a count
        try:
            if update_many:
                result = self.collection.update_many(filter_criteria, update_data)
            else:
                result = self.collection.update_one(filter_criteria, update_data)
            return result.modified_count
        except Exception as e:
            print(f"Error updating documents: {e}")
            return None
            
    def delete(self, filter_criteria, delete_many=False):
        """
        Deletes document(s) from the specified collection based on the filter criteria.

        Args:
            filter_criteria (dict): A dictionary representing the query filter
                                    to find documents to delete.
            delete_many (bool, optional): If True, deletes all matching documents.
                                       If False (default), deletes only the first match.

        Returns:
            int: The number of documents removed.
            None: If the MongoDB connection is not established.
        """
        if not self.collection:
            print("MongoDB connection not established.")
            return None

        try:
            if delete_many:
                result = self.collection.delete_many(filter_criteria)
            else:
                result = self.collection.delete_one(filter_criteria)
            return result.deleted_count
        except Exception as e:
            print(f"Error deleting documents: {e}")
            return None